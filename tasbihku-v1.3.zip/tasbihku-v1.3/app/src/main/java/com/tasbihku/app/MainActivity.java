package com.tasbihku.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import com.google.android.gms.ads.*;

public class MainActivity extends Activity {
  TasbihView view;
  AdView adView;

  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(14,16,20));
    getWindow().setNavigationBarColor(Color.rgb(9,10,13));

    FrameLayout root = new FrameLayout(this);
    view = new TasbihView(this);
    root.addView(view, new FrameLayout.LayoutParams(-1,-1));

    adView = new AdView(this);
    adView.setAdUnitId("ca-app-pub-3940256099942544/9214589741"); // Google test banner
    int adHeight = (int)(60 * getResources().getDisplayMetrics().density);
    FrameLayout.LayoutParams adLp = new FrameLayout.LayoutParams(-1, adHeight, Gravity.BOTTOM);
    root.addView(adView, adLp);
    MobileAds.initialize(this, status -> loadBanner());
    setContentView(root);
  }

  void loadBanner(){
    int widthPx = getResources().getDisplayMetrics().widthPixels;
    float density = getResources().getDisplayMetrics().density;
    int widthDp = (int)(widthPx / density);
    adView.setAdSize(AdSize.getAnchoredAdaptiveBannerAdSize(AdSize.BANNER.getOrientation(), widthDp));
    adView.loadAd(new AdRequest.Builder().build());
  }

  @Override protected void onDestroy(){ if(adView!=null) adView.destroy(); super.onDestroy(); }

  class TasbihView extends View {
    Paint p=new Paint(3); SharedPreferences sp; int count,total,target=33; String dzikir="استغفر الله العظيم"; boolean vibrate=true;
    int W,H; String[] dzs={"استغفر الله العظيم","سُبْحَانَ اللهِ","الْحَمْدُ لِلَّهِ","اللهُ أَكْبَرُ","لَا إِلٰهَ إِلَّا اللهُ"};
    int[] targets={33,99,100,1000};
    TasbihView(Context c){super(c);sp=getSharedPreferences("tasbih",0);count=sp.getInt("count",0);total=sp.getInt("total",0);target=sp.getInt("target",33);dzikir=sp.getString("dzikir",dzikir);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(a);c.drawText(s,x,y,p);}
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);}
    @Override protected void onDraw(Canvas c){
      W=getWidth();H=getHeight();
      int fg=Color.rgb(240,242,247),mut=Color.rgb(178,183,195),panel=Color.rgb(49,52,60);
      c.drawColor(Color.rgb(14,16,20));
      txt(c,"TasbihKu",28,62,30,fg,Paint.Align.LEFT);
      txt(c,"⋮",W-28,62,34,mut,Paint.Align.CENTER);
      round(c,28,88,W-28,238,38,panel);
      txt(c,String.valueOf(count),W/2-22,151,78,fg,Paint.Align.RIGHT);txt(c,"/",W/2+2,151,34,mut,Paint.Align.CENTER);txt(c,String.valueOf(target),W/2+34,151,30,fg,Paint.Align.LEFT);
      txt(c,"Total: "+total,W/2,190,29,fg,Paint.Align.CENTER);
      round(c,Math.max(100,W/2-155),202,Math.min(W-100,W/2+155),242,22,Color.rgb(58,61,70));txt(c,dzikir,W/2,229,19,fg,Paint.Align.CENTER);txt(c,"⌄",W/2+125,229,24,mut,Paint.Align.CENTER);
      drawBeads(c,W/2,H*0.52f,Math.min(W*0.39f,170));
      round(c,162,H-116,W-162,H-60,35,panel);
      txt(c,"◉",W/2-92,H-81,25,fg,Paint.Align.CENTER);txt(c,"↻",W/2,H-80,32,fg,Paint.Align.CENTER);txt(c,"▥",W/2+92,H-80,27,fg,Paint.Align.CENTER);
    }
    void drawBeads(Canvas c,float cx,float cy,float r){int n=32;p.setColor(Color.rgb(235,238,245));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(7);c.drawCircle(cx,cy,r,p);p.setStyle(Paint.Style.FILL);for(int i=0;i<n;i++){double a=-Math.PI/2+i*(2*Math.PI/n);float x=cx+(float)Math.cos(a)*r;float y=cy+(float)Math.sin(a)*r;c.drawCircle(x,y,17,p);}p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);c.drawCircle(cx,cy,34,p);p.setStyle(Paint.Style.FILL);c.drawCircle(cx,cy,13,p);}
    @Override public boolean onTouchEvent(MotionEvent e){
      if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();
      if(y>88&&y<200&&x>W/2-180&&x<W/2+180){pickTarget();return true;}
      if(y>=200&&y<250&&x>W/2-180&&x<W/2+180){pickDzikir();return true;}
      if(y>270&&y<H-135){count++;total++;save();if(vibrate){Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null){if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(25,VibrationEffect.DEFAULT_AMPLITUDE));else v.vibrate(25);}}if(count==target)new AlertDialog.Builder(MainActivity.this).setTitle("Target tercapai").setMessage("MasyaAllah! "+target+" kali selesai.").setPositiveButton("OK",null).show();invalidate();return true;}
      if(y>H-130&&y<H-55){if(x<W/2-45){if(count>0)count--;if(total>0)total--;save();invalidate();}else if(x<W/2+45){count=0;save();invalidate();}else{vibrate=!vibrate;invalidate();}return true;}
      return true;
    }
    void save(){sp.edit().putInt("count",count).putInt("total",total).putInt("target",target).putString("dzikir",dzikir).apply();}
    void pickTarget(){final String[] a={"33","99","100","1000","Custom"};new AlertDialog.Builder(MainActivity.this).setTitle("Pilih target").setSingleChoiceItems(a,Arrays.asList(a).indexOf(String.valueOf(target)),(d,w)->{if(w<4){target=targets[w];save();invalidate();d.dismiss();}else{d.dismiss();final EditText e=new EditText(MainActivity.this);e.setInputType(2);e.setHint("Jumlah");new AlertDialog.Builder(MainActivity.this).setTitle("Target custom").setView(e).setPositiveButton("Simpan",(dd,ww)->{try{int v=Integer.parseInt(e.getText().toString());if(v>0)target=v;}catch(Exception ex){}save();invalidate();}).setNegativeButton("Batal",null).show();}}).show();}
    void pickDzikir(){new AlertDialog.Builder(MainActivity.this).setTitle("Pilih dzikir").setItems(dzs,(d,w)->{dzikir=dzs[w];save();invalidate();}).show();}
  }
}
