# Draft Google Play listing — TasbihKu

## Nama aplikasi
TasbihKu — Tasbih Digital

## Deskripsi singkat
Tasbih digital sederhana untuk membantu menghitung dzikir dengan nyaman.

## Deskripsi lengkap
TasbihKu membantu Anda menghitung dzikir secara sederhana dan praktis. Pilih dzikir, tentukan target, lalu ketuk area tasbih untuk menambah hitungan.

Fitur versi awal:
- Counter dzikir yang mudah digunakan
- Target 33, 99, 100, 1000, atau custom
- Pilihan beberapa dzikir Arab
- Getaran saat hitungan bertambah
- Undo dan reset
- Penyimpanan hitungan di perangkat
- Tampilan gelap yang nyaman
- Banner iklan pada versi gratis

TasbihKu dirancang agar fungsi utama tetap sederhana dan tidak terganggu oleh pop-up iklan.

## Kategori yang disarankan
Lifestyle / Tools (pilihan final disesuaikan dengan Play Console).

## Catatan publikasi
Tambahkan email dukungan, URL privacy policy publik, ikon 512x512, feature graphic, screenshot, Data safety, content rating, dan AAB yang sudah ditandatangani.
