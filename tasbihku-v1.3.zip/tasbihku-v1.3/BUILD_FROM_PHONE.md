# Cara build TasbihKu dari HP memakai GitHub Actions

1. Buat akun/login GitHub.
2. Buat repository baru, misalnya `tasbihku`.
3. Ekstrak ZIP ini di HP, lalu upload seluruh isi folder ke repository (jangan upload file ZIP sebagai satu-satunya file).
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build TasbihKu**.
6. Tekan **Run workflow**.
7. Tunggu sampai status hijau.
8. Buka hasil workflow → bagian **Artifacts** → download `TasbihKu-v1.3-builds`.
9. Ekstrak ZIP hasil artifact. File `app-debug.apk` dapat dipasang di HP untuk pengujian.

Catatan:
- APK debug adalah untuk pengujian.
- AAB adalah format publikasi Google Play, tetapi untuk rilis publik kita masih perlu menyiapkan signing/upload key dan Play App Signing.
- Jangan mengganti test AdMob ID dengan ID produksi sebelum aplikasi dan akun AdMob siap.
