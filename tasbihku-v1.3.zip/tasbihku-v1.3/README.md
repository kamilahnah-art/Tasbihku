# TasbihKu v1.3

Tasbih digital Android dengan counter, target, pilihan dzikir, getar, undo/reset, penyimpanan lokal, dark UI, dan banner AdMob test di bagian bawah.

## Build
- compileSdk 36
- targetSdk 36
- minSdk 23
- Debug APK: `gradle assembleDebug`
- Release bundle: `gradle bundleRelease`

Lihat `BUILD_FROM_PHONE.md` untuk build menggunakan GitHub Actions tanpa laptop.

**Penting:** AdMob di project masih memakai test IDs resmi Google. Jangan gunakan test IDs untuk produksi.
