# Kebijakan Privasi TasbihKu

**Versi:** 1.0 — 7 Oktober 2026

TasbihKu adalah aplikasi penghitung dzikir. Versi ini tidak memerlukan akun atau login.

## Data lokal
Hitungan, target, pilihan dzikir, dan pengaturan dasar dapat disimpan di perangkat agar aplikasi dapat melanjutkan penggunaan setelah ditutup.

## Iklan
Versi yang menggunakan Google AdMob dapat memproses informasi perangkat dan data terkait iklan sesuai kebijakan dan teknologi Google untuk menayangkan, mengukur, dan mencegah penyalahgunaan iklan. Selama pengembangan aplikasi, kami menggunakan unit iklan pengujian Google.

## Perubahan
Kebijakan ini dapat diperbarui ketika fitur aplikasi berubah, termasuk ketika analitik atau layanan pihak ketiga ditambahkan.

## Kontak
Email kontak aplikasi akan ditambahkan sebelum publikasi di Google Play.
